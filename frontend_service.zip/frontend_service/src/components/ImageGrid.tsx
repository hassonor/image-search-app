import React, { useEffect, useState } from 'react';
import { fetchImages } from '../api/client';
import { Grid, Card, CardMedia, Typography } from '@mui/material';

interface ImageItem {
  image_id: number;
  image_url: string;
  score: number;
}

interface ImageGridProps {
  query: string;
  page: number;
}

const ImageGrid: React.FC<ImageGridProps> = ({ query, page }) => {
  const [images, setImages] = useState<ImageItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!query) return;
    setLoading(true);
    setError(null);
    fetchImages(query, page)
      .then((data) => {
        setImages(data.results);
      })
      .catch((err) => {
        console.error('Failed to fetch images', err);
        setError('Failed to fetch images');
      })
      .finally(() => {
        setLoading(false);
      });
  }, [query, page]);

  if (!query) {
    return <Typography>Enter a query to search for images.</Typography>;
  }

  if (loading) {
    return <Typography>Loading images...</Typography>;
  }

  if (error) {
    return <Typography color="error">{error}</Typography>;
  }

  if (images.length === 0) {
    return <Typography>No images found for "{query}"</Typography>;
  }

  return (
    <Grid container spacing={2}>
      {images.map((img) => (
        <Grid item key={img.image_id} xs={12} sm={6} md={4}>
          <Card>
            <CardMedia
              component="img"
              image={img.image_url}
              alt={`Image ${img.image_id}`}
              style={{ maxHeight: '200px', objectFit: 'cover' }}
            />
            <Typography variant="body2" style={{ padding: '8px' }}>Score: {img.score.toFixed(2)}</Typography>
          </Card>
        </Grid>
      ))}
    </Grid>
  );
};

export default ImageGrid;
