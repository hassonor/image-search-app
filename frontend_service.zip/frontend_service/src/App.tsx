import React, { useState } from 'react';
import SearchBar from './components/SearchBar';
import ImageGrid from './components/ImageGrid';
import PaginationControls from './components/PaginationControls';
import { Container, Typography } from '@mui/material';

function App() {
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);

  return (
    <Container maxWidth="md" style={{ padding: '20px' }}>
      <Typography variant="h4" component="h1" style={{ marginBottom: '20px' }}>
        Image Search
      </Typography>
      <SearchBar onSearch={(q) => { setQuery(q); setPage(1); }} />
      {query && <ImageGrid query={query} page={page} />}
      {query && <PaginationControls page={page} onPageChange={(p) => setPage(p)} />}
    </Container>
  );
}

export default App;
